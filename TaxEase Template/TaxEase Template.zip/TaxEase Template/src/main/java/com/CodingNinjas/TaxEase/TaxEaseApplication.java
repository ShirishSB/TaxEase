package com.CodingNinjas.TaxEase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaxEaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaxEaseApplication.class, args);
	}

}
